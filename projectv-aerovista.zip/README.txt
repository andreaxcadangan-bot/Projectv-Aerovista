AeroVista Flutter project

Asset paths have been corrected to match the files in the ZIP:
- assets/index.html
- assets/aerovista-background.mp4
- assets/qris.png
- assets/about-you-x-multo.mp3

Build: flutter pub get && flutter build apk --release
Note: this fixes the missing-asset error reported by the builder; a full Release build has not been run here.

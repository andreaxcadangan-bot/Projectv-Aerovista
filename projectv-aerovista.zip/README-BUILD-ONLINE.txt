AeroVista — Release APK via GitHub Actions

This ZIP includes a GitHub Actions workflow at:
.github/workflows/release-apk.yml

How to use from an Android phone:
1. Sign in to GitHub and create a new repository. Do not add a README/license/gitignore if you want to upload these files as-is.
2. Extract this ZIP on your phone if possible, then upload the project files and folders to the repository root. Ensure .github/workflows/release-apk.yml is included; hidden folders must not be omitted.
3. Open the repository on GitHub -> Actions -> Build AeroVista Release APK -> Run workflow.
4. Wait for the workflow to finish. If successful, open the completed run and download the artifact named aerovista-release-apk.
5. Extract the downloaded artifact ZIP to get app-release.apk.

Important:
- This workflow is a build configuration; the APK has not been compiled or verified in this environment.
- GitHub Actions may report dependency or Android Gradle errors; if so, share the failed step's log so it can be corrected.
- Do not commit signing keys, passwords, or private credentials to a public repository. This workflow creates a standard unsigned-by-you release APK suitable for testing; Play Store distribution generally requires signing and additional release preparation.
